import sys
if __name__ == '__main__':
    from dragon_player.cli import main
    main()
